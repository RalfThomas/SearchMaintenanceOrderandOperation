sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend("zi2d.eam.orderandoperation.monitors1.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
